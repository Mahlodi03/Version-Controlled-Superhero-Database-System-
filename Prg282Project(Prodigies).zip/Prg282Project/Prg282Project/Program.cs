﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prg282Project.DataLayer;
using Prg282Project.BusinessLayer;
using System.Windows.Forms;
using PRG282_Project;
using Loginform;

namespace Prg282Project
{
    internal class Program
    {

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 👇 This line determines your startup form
            Application.Run(new Login());
        }
    }
}
