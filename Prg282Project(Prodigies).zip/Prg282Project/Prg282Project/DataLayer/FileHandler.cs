﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prg282Project.DataLayer
{
    public class FileHandler
    {
        List<Superhero> superheroes = new List<Superhero>();

        readonly string path = "C:\\Users\\thabz\\Downloads\\Prg282-TextFiles\\SuperHeroes.txt";

        public string Path { get => path;  }
        public List<Superhero> Superheroes { get => superheroes; set => superheroes = value; }

        //Takes instance of Superhero as an argument then writes it to a file 
        public void WriteFile(Superhero superhero)
        {
            using (StreamWriter writer = new StreamWriter(Path,true))
            {
   
                writer.WriteLine(superhero.ToString());
                 
            }
        }

        //Here we read from a file and store return that data of type string so that we format it into a List<Superhero>
             public List<string> ReadFile()
            {
                List<string> data = new List<string>();
                using (StreamReader reader = new StreamReader(path))
                {
                
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        data.Add(line);
                    }
                
                }
                return data;

            }

        //Here we Format the string from Readfile to List<SuperHero> so that we are able manipulate the data e.g filter/search and etc.
        //We can't do that with data directly from a txt file since it's strictly a string
            public void FormatData(List<string> info)
            {
            Superheroes.Clear();
            foreach (string line in info)
                {
                    string[] arrSuperhero = line.Split('|');
                    Superhero newHero = new Superhero(int.Parse(arrSuperhero[0]), arrSuperhero[1], arrSuperhero[2], arrSuperhero[3], int.Parse(arrSuperhero[4]), double.Parse(arrSuperhero[5]), arrSuperhero[6], arrSuperhero[7]);
                    Superheroes.Add(newHero);
                   
                }
            }

            //Here we update both the text file and the in-memory data
            public void UpdateData(Superhero updatedHero)
            {
                for (int i = 0; i < Superheroes.Count; i++)
                {
                    if (Superheroes[i].Id == updatedHero.Id)
                    {
                        Superheroes[i] = updatedHero;
                        break;
                    }
                }
                using (StreamWriter writer = new StreamWriter(Path, false))
                {
                    foreach (Superhero hero in Superheroes)
                    {
                        writer.WriteLine(hero.ToString());
                    }
                }

            }


        //This method clears the existing txt file and uses (temporary)data from List<Superhero> to store back all the data excluding the deleted Superhero
        public void DeleteSuperHero(int id)
        {
            //First we remove from in-memory list
            Superhero heroToRemove = Superheroes.FirstOrDefault(h => h.Id == id);
            if (heroToRemove != null)
            {
                Superheroes.Remove(heroToRemove);
            }

            // Then we overwrite the file with the remaining heroes
            using (StreamWriter writer = new StreamWriter(Path, false)) 
            {
                foreach (Superhero superhero in Superheroes)
                {
                    writer.WriteLine(superhero.ToString());
                }
            }
        }


    }
}
