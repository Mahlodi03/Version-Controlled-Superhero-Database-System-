﻿namespace PRG282_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonAddHero = new System.Windows.Forms.Button();
            this.groupBoxGender = new System.Windows.Forms.GroupBox();
            this.radioButtonMale = new System.Windows.Forms.RadioButton();
            this.radioButtonFemale = new System.Windows.Forms.RadioButton();
            this.textBoxPower = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxAge = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxMark = new System.Windows.Forms.TextBox();
            this.labelEx = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.heroMark_Update = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.heroPower_Update = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.heroGender_Update = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.heroAge_Update = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.heroName_Update = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.heroId_Update = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.heroID_delete = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.buttonPrintTextFIle = new System.Windows.Forms.Button();
            this.labelCRank = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.labelBRank = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.labelARank = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labelSRank = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.labelAverageExamMark = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelAverageAge = new System.Windows.Forms.Label();
            this.labelAge = new System.Windows.Forms.Label();
            this.labelTotalHeros = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBoxGender.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1005, 614);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkCyan;
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.buttonAddHero);
            this.tabPage1.Controls.Add(this.groupBoxGender);
            this.tabPage1.Controls.Add(this.textBoxPower);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textBoxAge);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.textBoxMark);
            this.tabPage1.Controls.Add(this.labelEx);
            this.tabPage1.Controls.Add(this.textBoxName);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.ForeColor = System.Drawing.Color.Cornsilk;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(997, 585);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ADD";
            // 
            // buttonAddHero
            // 
            this.buttonAddHero.AutoSize = true;
            this.buttonAddHero.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonAddHero.ForeColor = System.Drawing.Color.Black;
            this.buttonAddHero.Location = new System.Drawing.Point(3, 538);
            this.buttonAddHero.Name = "buttonAddHero";
            this.buttonAddHero.Size = new System.Drawing.Size(991, 44);
            this.buttonAddHero.TabIndex = 9;
            this.buttonAddHero.Text = "ADD HERO";
            this.buttonAddHero.UseVisualStyleBackColor = true;
            this.buttonAddHero.Click += new System.EventHandler(this.buttonAddHero_Click);
            // 
            // groupBoxGender
            // 
            this.groupBoxGender.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxGender.AutoSize = true;
            this.groupBoxGender.Controls.Add(this.radioButtonMale);
            this.groupBoxGender.Controls.Add(this.radioButtonFemale);
            this.groupBoxGender.Location = new System.Drawing.Point(23, 323);
            this.groupBoxGender.Name = "groupBoxGender";
            this.groupBoxGender.Size = new System.Drawing.Size(367, 207);
            this.groupBoxGender.TabIndex = 8;
            this.groupBoxGender.TabStop = false;
            this.groupBoxGender.Text = "GENDER";
            // 
            // radioButtonMale
            // 
            this.radioButtonMale.AutoSize = true;
            this.radioButtonMale.Location = new System.Drawing.Point(16, 64);
            this.radioButtonMale.Name = "radioButtonMale";
            this.radioButtonMale.Size = new System.Drawing.Size(58, 20);
            this.radioButtonMale.TabIndex = 9;
            this.radioButtonMale.TabStop = true;
            this.radioButtonMale.Text = "Male";
            this.radioButtonMale.UseVisualStyleBackColor = true;
            this.radioButtonMale.CheckedChanged += new System.EventHandler(this.radioButtonMale_CheckedChanged);
            // 
            // radioButtonFemale
            // 
            this.radioButtonFemale.AutoSize = true;
            this.radioButtonFemale.Location = new System.Drawing.Point(16, 21);
            this.radioButtonFemale.Name = "radioButtonFemale";
            this.radioButtonFemale.Size = new System.Drawing.Size(74, 20);
            this.radioButtonFemale.TabIndex = 9;
            this.radioButtonFemale.TabStop = true;
            this.radioButtonFemale.Text = "Female";
            this.radioButtonFemale.UseVisualStyleBackColor = true;
            this.radioButtonFemale.CheckedChanged += new System.EventHandler(this.radioButtonFemale_CheckedChanged);
            // 
            // textBoxPower
            // 
            this.textBoxPower.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPower.Location = new System.Drawing.Point(23, 102);
            this.textBoxPower.Name = "textBoxPower";
            this.textBoxPower.Size = new System.Drawing.Size(393, 22);
            this.textBoxPower.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "SuperPower";
            // 
            // textBoxAge
            // 
            this.textBoxAge.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAge.Location = new System.Drawing.Point(23, 181);
            this.textBoxAge.Name = "textBoxAge";
            this.textBoxAge.Size = new System.Drawing.Size(393, 22);
            this.textBoxAge.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "AGE";
            // 
            // textBoxMark
            // 
            this.textBoxMark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMark.Location = new System.Drawing.Point(23, 266);
            this.textBoxMark.Name = "textBoxMark";
            this.textBoxMark.Size = new System.Drawing.Size(393, 22);
            this.textBoxMark.TabIndex = 3;
            // 
            // labelEx
            // 
            this.labelEx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelEx.AutoSize = true;
            this.labelEx.Location = new System.Drawing.Point(20, 247);
            this.labelEx.Name = "labelEx";
            this.labelEx.Size = new System.Drawing.Size(74, 16);
            this.labelEx.TabIndex = 2;
            this.labelEx.Text = "Exam Mark";
            // 
            // textBoxName
            // 
            this.textBoxName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxName.Location = new System.Drawing.Point(23, 34);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(393, 22);
            this.textBoxName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "NAME";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DarkCyan;
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.buttonUpdate);
            this.tabPage2.Controls.Add(this.heroMark_Update);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.heroPower_Update);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.heroGender_Update);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.heroAge_Update);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.heroName_Update);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.heroId_Update);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.ForeColor = System.Drawing.Color.White;
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(997, 585);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "UPDATE";
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.ForeColor = System.Drawing.Color.Black;
            this.buttonUpdate.Location = new System.Drawing.Point(252, 420);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(198, 37);
            this.buttonUpdate.TabIndex = 13;
            this.buttonUpdate.Text = "Update Hero";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // heroMark_Update
            // 
            this.heroMark_Update.Location = new System.Drawing.Point(258, 362);
            this.heroMark_Update.Name = "heroMark_Update";
            this.heroMark_Update.Size = new System.Drawing.Size(193, 22);
            this.heroMark_Update.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(163, 368);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 16);
            this.label12.TabIndex = 11;
            this.label12.Text = "Exam Mark";
            // 
            // heroPower_Update
            // 
            this.heroPower_Update.Location = new System.Drawing.Point(258, 303);
            this.heroPower_Update.Name = "heroPower_Update";
            this.heroPower_Update.Size = new System.Drawing.Size(193, 22);
            this.heroPower_Update.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(163, 306);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "SuperPower";
            // 
            // heroGender_Update
            // 
            this.heroGender_Update.Location = new System.Drawing.Point(258, 240);
            this.heroGender_Update.Name = "heroGender_Update";
            this.heroGender_Update.Size = new System.Drawing.Size(193, 22);
            this.heroGender_Update.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(163, 243);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Gender";
            // 
            // heroAge_Update
            // 
            this.heroAge_Update.Location = new System.Drawing.Point(258, 182);
            this.heroAge_Update.Name = "heroAge_Update";
            this.heroAge_Update.Size = new System.Drawing.Size(193, 22);
            this.heroAge_Update.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(163, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Age";
            // 
            // heroName_Update
            // 
            this.heroName_Update.Location = new System.Drawing.Point(258, 119);
            this.heroName_Update.Name = "heroName_Update";
            this.heroName_Update.Size = new System.Drawing.Size(193, 22);
            this.heroName_Update.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(163, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name";
            // 
            // heroId_Update
            // 
            this.heroId_Update.Location = new System.Drawing.Point(258, 67);
            this.heroId_Update.Name = "heroId_Update";
            this.heroId_Update.Size = new System.Drawing.Size(193, 22);
            this.heroId_Update.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(163, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "SuperHero ID";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkCyan;
            this.tabPage3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage3.BackgroundImage")));
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tabPage3.Controls.Add(this.buttonDelete);
            this.tabPage3.Controls.Add(this.heroID_delete);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.ForeColor = System.Drawing.Color.White;
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(997, 585);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "DELETE";
            // 
            // buttonDelete
            // 
            this.buttonDelete.ForeColor = System.Drawing.Color.Black;
            this.buttonDelete.Location = new System.Drawing.Point(761, 35);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(176, 32);
            this.buttonDelete.TabIndex = 4;
            this.buttonDelete.Text = "DELETE";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // heroID_delete
            // 
            this.heroID_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heroID_delete.Location = new System.Drawing.Point(13, 41);
            this.heroID_delete.Name = "heroID_delete";
            this.heroID_delete.Size = new System.Drawing.Size(250, 26);
            this.heroID_delete.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.8F);
            this.label8.Location = new System.Drawing.Point(8, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 20);
            this.label8.TabIndex = 2;
            this.label8.Text = "SuperHeroID";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(997, 585);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "VIEW ALL";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(997, 585);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.DarkCyan;
            this.tabPage5.Controls.Add(this.label10);
            this.tabPage5.Controls.Add(this.buttonPrintTextFIle);
            this.tabPage5.Controls.Add(this.labelCRank);
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.labelBRank);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.labelARank);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.labelSRank);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.labelAverageExamMark);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.labelAverageAge);
            this.tabPage5.Controls.Add(this.labelAge);
            this.tabPage5.Controls.Add(this.labelTotalHeros);
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.ForeColor = System.Drawing.Color.White;
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(997, 585);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "GENERATE SUMMARY";
            // 
            // buttonPrintTextFIle
            // 
            this.buttonPrintTextFIle.ForeColor = System.Drawing.Color.Black;
            this.buttonPrintTextFIle.Location = new System.Drawing.Point(843, 29);
            this.buttonPrintTextFIle.Name = "buttonPrintTextFIle";
            this.buttonPrintTextFIle.Size = new System.Drawing.Size(125, 34);
            this.buttonPrintTextFIle.TabIndex = 14;
            this.buttonPrintTextFIle.Text = "Print";
            this.buttonPrintTextFIle.UseVisualStyleBackColor = true;
            this.buttonPrintTextFIle.Click += new System.EventHandler(this.buttonPrintTextFIle_Click);
            // 
            // labelCRank
            // 
            this.labelCRank.AutoSize = true;
            this.labelCRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelCRank.Location = new System.Drawing.Point(582, 545);
            this.labelCRank.Name = "labelCRank";
            this.labelCRank.Size = new System.Drawing.Size(20, 22);
            this.labelCRank.TabIndex = 13;
            this.labelCRank.Text = "2";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label19.Location = new System.Drawing.Point(303, 545);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(233, 22);
            this.label19.TabIndex = 12;
            this.label19.Text = "Total  C-Rank SuperHeroes";
            // 
            // labelBRank
            // 
            this.labelBRank.AutoSize = true;
            this.labelBRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelBRank.Location = new System.Drawing.Point(582, 491);
            this.labelBRank.Name = "labelBRank";
            this.labelBRank.Size = new System.Drawing.Size(20, 22);
            this.labelBRank.TabIndex = 11;
            this.labelBRank.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label17.Location = new System.Drawing.Point(303, 491);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(232, 22);
            this.label17.TabIndex = 10;
            this.label17.Text = "Total  B-Rank SuperHeroes";
            // 
            // labelARank
            // 
            this.labelARank.AutoSize = true;
            this.labelARank.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelARank.Location = new System.Drawing.Point(582, 439);
            this.labelARank.Name = "labelARank";
            this.labelARank.Size = new System.Drawing.Size(20, 22);
            this.labelARank.TabIndex = 9;
            this.labelARank.Text = "2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label14.Location = new System.Drawing.Point(303, 439);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(232, 22);
            this.label14.TabIndex = 8;
            this.label14.Text = "Total  A-Rank SuperHeroes";
            // 
            // labelSRank
            // 
            this.labelSRank.AutoSize = true;
            this.labelSRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelSRank.Location = new System.Drawing.Point(582, 384);
            this.labelSRank.Name = "labelSRank";
            this.labelSRank.Size = new System.Drawing.Size(20, 22);
            this.labelSRank.TabIndex = 7;
            this.labelSRank.Text = "2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label15.Location = new System.Drawing.Point(303, 384);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(232, 22);
            this.label15.TabIndex = 6;
            this.label15.Text = "Total  S-Rank SuperHeroes";
            // 
            // labelAverageExamMark
            // 
            this.labelAverageExamMark.AutoSize = true;
            this.labelAverageExamMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelAverageExamMark.Location = new System.Drawing.Point(582, 289);
            this.labelAverageExamMark.Name = "labelAverageExamMark";
            this.labelAverageExamMark.Size = new System.Drawing.Size(20, 22);
            this.labelAverageExamMark.TabIndex = 5;
            this.labelAverageExamMark.Text = "2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label13.Location = new System.Drawing.Point(303, 289);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(315, 22);
            this.label13.TabIndex = 4;
            this.label13.Text = "Average Exam Score of  SuperHeroes";
            // 
            // labelAverageAge
            // 
            this.labelAverageAge.AutoSize = true;
            this.labelAverageAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelAverageAge.Location = new System.Drawing.Point(582, 192);
            this.labelAverageAge.Name = "labelAverageAge";
            this.labelAverageAge.Size = new System.Drawing.Size(20, 22);
            this.labelAverageAge.TabIndex = 3;
            this.labelAverageAge.Text = "2";
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelAge.Location = new System.Drawing.Point(303, 192);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(250, 22);
            this.labelAge.TabIndex = 2;
            this.labelAge.Text = "Average Age of  SuperHeroes";
            // 
            // labelTotalHeros
            // 
            this.labelTotalHeros.AutoSize = true;
            this.labelTotalHeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.labelTotalHeros.Location = new System.Drawing.Point(582, 104);
            this.labelTotalHeros.Name = "labelTotalHeros";
            this.labelTotalHeros.Size = new System.Drawing.Size(20, 22);
            this.labelTotalHeros.TabIndex = 1;
            this.labelTotalHeros.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label9.Location = new System.Drawing.Point(303, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(260, 22);
            this.label9.TabIndex = 0;
            this.label9.Text = "Total  Number of  SuperHeroes";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F);
            this.label10.Location = new System.Drawing.Point(358, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(151, 51);
            this.label10.TabIndex = 15;
            this.label10.Text = "Report";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(556, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(328, 486);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(568, 97);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(367, 327);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 614);
            this.Controls.Add(this.tabControl1);
            this.MinimumSize = new System.Drawing.Size(700, 500);
            this.Name = "Form1";
            this.Text = "One Kick Academy";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBoxGender.ResumeLayout(false);
            this.groupBoxGender.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxPower;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxAge;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxMark;
        private System.Windows.Forms.Label labelEx;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.GroupBox groupBoxGender;
        private System.Windows.Forms.RadioButton radioButtonMale;
        private System.Windows.Forms.RadioButton radioButtonFemale;
        private System.Windows.Forms.Button buttonAddHero;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox heroID_delete;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox heroAge_Update;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox heroName_Update;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox heroId_Update;
        private System.Windows.Forms.TextBox heroPower_Update;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox heroGender_Update;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox heroMark_Update;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Label labelAverageAge;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelTotalHeros;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelARank;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelSRank;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label labelAverageExamMark;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonPrintTextFIle;
        private System.Windows.Forms.Label labelCRank;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label labelBRank;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

