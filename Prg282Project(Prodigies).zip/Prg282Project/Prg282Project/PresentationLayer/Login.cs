﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRG282_Project;

namespace Loginform
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void buttonS_Click(object sender, EventArgs e)
        {
            string filePath = "C:\\Users\\thabz\\Downloads\\Prg282-TextFiles\\login.txt";
            string inputUsername = tbUserName.Text.Trim();
            string inputPassword = tbPassword.Text;

            bool isCorrect = false;

            if (File.Exists(filePath))
            {
                var lines = System.IO.File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 2)
                    {
                        string storedUsername = parts[0].Trim();
                        string storedPassword = parts[1].Trim();

                        if (inputUsername == storedUsername && inputPassword == storedPassword)
                        {
                            isCorrect = true;
                            break;
                        }
                    }
                }
            }

            if (isCorrect)
            {
               Form1 form1 = new Form1();
                form1.Show();
            }
            else
            {
                MessageBox.Show("Incorrect", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
