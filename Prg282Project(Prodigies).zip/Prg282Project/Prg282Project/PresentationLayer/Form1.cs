﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Prg282Project.DataLayer;
using Prg282Project.BusinessLayer;
using Prg282Project;

namespace PRG282_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            filehandler.FormatData(filehandler.ReadFile());
        }

        FileHandler filehandler = new FileHandler();
        DataHandler dataHandler = new DataHandler();

        string gender;
        private void radioButtonFemale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void radioButtonMale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }
        private void buttonAddHero_Click(object sender, EventArgs e)
        {
            ResetTextboxColors();

            bool valid = true;

            // Basic validation for empty textboxes
            if (string.IsNullOrWhiteSpace(textBoxName.Text))
            {
                HighlightInvalid(textBoxName);
                valid = false;
            }
            if (string.IsNullOrWhiteSpace(textBoxPower.Text))
            {
                HighlightInvalid(textBoxPower);
                valid = false;
            }
            if (string.IsNullOrWhiteSpace(textBoxAge.Text))
            {
                HighlightInvalid(textBoxAge);
                valid = false;
            }
            if (string.IsNullOrWhiteSpace(textBoxMark.Text))
            {
                HighlightInvalid(textBoxMark);
                valid = false;
            }
            if (string.IsNullOrWhiteSpace(gender))
            {
                MessageBox.Show("Please select a gender.", "Validation Error");
                valid = false;
            }

            // Numeric validation
            if (!int.TryParse(textBoxAge.Text, out int age) || age <= 0)
            {
                HighlightInvalid(textBoxAge);
                MessageBox.Show("Please enter a valid age.", "Validation Error");
                valid = false;
            }

            if (!double.TryParse(textBoxMark.Text, out double examMark) || examMark < 0)
            {
                HighlightInvalid(textBoxMark);
                MessageBox.Show("Please enter a valid exam mark.", "Validation Error");
                valid = false;
            }

            if (!valid) return; 

            // If all valid
            int id = dataHandler.CreateId();
            string rank = dataHandler.CalculateRank(examMark);
            string threatLevel = dataHandler.CalculateThreatLevel(rank);
            
            Superhero superhero = new Superhero(id, textBoxName.Text, textBoxPower.Text, gender, age, examMark, rank, threatLevel);
            dataHandler.validateInsertSuperhero(superhero);
            ResetTextboxColors();
            RefreshDataGrid();

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            ResetTextboxColors();

            if (string.IsNullOrWhiteSpace(heroId_Update.Text) || !int.TryParse(heroId_Update.Text, out int id))
            {
                HighlightInvalid(heroId_Update);
                MessageBox.Show("Please enter a valid numeric ID.", "Validation Error");
                return;
            }

            // Allow optional fields for partial updates
            int age = -1;
            double examMark = -1;

            if (!string.IsNullOrWhiteSpace(heroAge_Update.Text) && !int.TryParse(heroAge_Update.Text, out age))
            {
                HighlightInvalid(heroAge_Update);
                MessageBox.Show("Invalid age entered.", "Validation Error");
                return;
            }

            if (!string.IsNullOrWhiteSpace(heroMark_Update.Text) && !double.TryParse(heroMark_Update.Text, out examMark))
            {
                HighlightInvalid(heroMark_Update);
                MessageBox.Show("Invalid exam mark entered.", "Validation Error");
                return;
            }

            Superhero updatedHero = new Superhero(
                id,
                heroName_Update.Text,
                heroPower_Update.Text,
                heroGender_Update.Text,
                age,
                examMark,
                "",  // Rank recalculated in DataHandler
                ""   // Threat recalculated in DataHandler
            );

            ResetTextboxColors();
            dataHandler.validateUpdateSuperhero(updatedHero);
            RefreshDataGrid();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            ResetTextboxColors();

            if (string.IsNullOrWhiteSpace(heroID_delete.Text) || !int.TryParse(heroID_delete.Text, out int id))
            {
                HighlightInvalid(heroID_delete);
                MessageBox.Show("Please enter a valid numeric ID to delete.", "Validation Error");
                return;
            }

            dataHandler.validateDeleteSuperhero(id);
            RefreshDataGrid();
        }

        private void RefreshDataGrid()
        {
            filehandler.FormatData(filehandler.ReadFile()); // refresh in-memory list
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = filehandler.Superheroes;
            GenerateReport();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshDataGrid();
        }

        private void GenerateReport()
        {
            filehandler.FormatData(filehandler.ReadFile());
            List<string> reportData = dataHandler.ReportInfo(filehandler);
            labelTotalHeros.Text = reportData[0];
            labelAverageAge.Text = reportData[1];
            labelAverageExamMark.Text = reportData[2] + '%';
            labelSRank.Text = reportData[3];
            labelARank.Text = reportData[4];
            labelBRank.Text = reportData[5];
            labelCRank.Text = reportData[6];
        }

        private void buttonPrintTextFIle_Click(object sender, EventArgs e)
        {
            dataHandler.GenerateReportFile(filehandler);
        }

        private void HighlightInvalid(TextBox txt)
        {
            txt.BackColor = Color.LightCoral;
        }

        private void ResetTextboxColors()
        {
            // Reset all TextBoxes to white
            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                    c.BackColor = Color.White;
            }
        }
    }
}
