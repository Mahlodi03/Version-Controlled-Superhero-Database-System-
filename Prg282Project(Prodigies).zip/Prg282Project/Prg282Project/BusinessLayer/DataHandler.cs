﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Prg282Project.DataLayer;

namespace Prg282Project.BusinessLayer
{
    internal class DataHandler
    {
        FileHandler fileHandler = new FileHandler();
        public int CreateId()
        {
            Random random = new Random();
            int id = random.Next(1000, 10000);
            FileHandler fileHandler = new FileHandler();
            foreach (Superhero hero in fileHandler.Superheroes)
            {
                while (id == hero.Id)
                {
                     id = random.Next(1000, 10000);
                }
            }
            return id;
        }
        public string CalculateRank(double examMark)
        {
            
            string rank = "Null";

            if (examMark >= 81 && examMark <= 100)
           {
             rank = "S-Rank";
           }
            else if (examMark >= 61 && examMark <= 80)
           {
             rank = "A-Rank";
           }
            else if (examMark >= 41 && examMark <= 60)
           {
              rank = "B-Rank";
           }
             else if (examMark >= 0 && examMark <= 40)
           {
              rank = "C-Rank";
           }
           else {
          throw new Exception("Unkown rank due to invalid exam mark");
        }
   

            return rank;

        }

        public string CalculateThreatLevel(string heroRank)
        {
            string threatLevel = "Null";
            switch (heroRank)
            {
                case "S-Rank":
                    threatLevel = "Finals Week";
                    break;
                case "A-Rank":
                    threatLevel = "Midterm Madness";
                    break;
                case "B-Rank":
                    threatLevel = "Group Project Gone Wrong";
                    break;
                case "C-Rank":
                    threatLevel = "Pop Quiz";
                    break;
                default:
                    threatLevel = "Threat level is unknown";
                    break;
            }


            return threatLevel;
        }

        public void validateInsertSuperhero(Superhero superhero)
        {

            // Refresh in-memory list
            fileHandler.FormatData(fileHandler.ReadFile());

            // Basic field validation
            if (string.IsNullOrWhiteSpace(superhero.Name) ||
                string.IsNullOrWhiteSpace(superhero.SuperPower) ||
                string.IsNullOrWhiteSpace(superhero.Gender) ||
                superhero.Age <= 0 || superhero.ExamMark < 0)
            {
                MessageBox.Show("Please fill in all the required fields correctly.", "Validation Error");
                return;
            }


            // Validation passed — insert into text file
            fileHandler.WriteFile(superhero);
            MessageBox.Show("Hero created successfully!");
        }

        public void validateUpdateSuperhero(Superhero updatedHero)
        {
            // Refresh in-memory list
            fileHandler.FormatData(fileHandler.ReadFile());

            // Check that ID is valid
            if (updatedHero.Id <= 0)
            {
                MessageBox.Show("Invalid ID entered!", "Error");
                return;
            }

            // Find hero by ID
            Superhero oldHero = fileHandler.Superheroes.FirstOrDefault(h => h.Id == updatedHero.Id);

            if (oldHero == null)
            {
                MessageBox.Show("Hero not found!", "Error");
                return;
            }

            // Replace empty or invalid fields with old values
            if (string.IsNullOrWhiteSpace(updatedHero.Name))
                updatedHero.Name = oldHero.Name;

            if (string.IsNullOrWhiteSpace(updatedHero.SuperPower))
                updatedHero.SuperPower = oldHero.SuperPower;

            if (string.IsNullOrWhiteSpace(updatedHero.Gender))
                updatedHero.Gender = oldHero.Gender;

            if (updatedHero.Age <= 0)
                updatedHero.Age = oldHero.Age;

            if (updatedHero.ExamMark < 0)
                updatedHero.ExamMark = oldHero.ExamMark;

            // Recalculate rank and threat based on the new or old exam mark
            updatedHero.Rank = CalculateRank(updatedHero.ExamMark);
            updatedHero.ThreatLevel = CalculateThreatLevel(updatedHero.Rank);

            // Perform update
            fileHandler.UpdateData(updatedHero);
            MessageBox.Show("Hero updated successfully!");
        }

        public void validateDeleteSuperhero(int id)
        {
            // Refresh in-memory list
            fileHandler.FormatData(fileHandler.ReadFile());

            // Validate ID
            if (id <= 0)
            {
                MessageBox.Show("Please enter a valid numeric ID!", "Error");
                return;
            }

            // Find hero by ID
            Superhero oldHero = fileHandler.Superheroes.FirstOrDefault(h => h.Id == id);

            if (oldHero == null)
            {
                MessageBox.Show("Hero not found!", "Error");
                return;
            }

            // Delete hero
            fileHandler.DeleteSuperHero(id);
            MessageBox.Show("Hero deleted successfully!");
        }

        public List<string> ReportInfo(FileHandler handler)
        {
            
            List<string> report = new List<string>();

            int totalNumberOfHeroes = handler.Superheroes.Count;
            double averageAge = 0;
            double examScoreAverage = 0;

            foreach (Superhero hero in handler.Superheroes)
            {
                //Sums every hero's age
                averageAge += hero.Age;
            }
            averageAge = Math.Floor(averageAge/totalNumberOfHeroes);

            foreach (Superhero hero in handler.Superheroes)
            {
                //Sums every hero's exam mark
                examScoreAverage += hero.ExamMark;
            }
            examScoreAverage = Math.Round((examScoreAverage / totalNumberOfHeroes),2);

            //Counts the number of hero's in each rank
            int sHeroes = handler.Superheroes.Count(h => h.Rank == "S-Rank");
            int aHeroes = handler.Superheroes.Count(h => h.Rank == "A-Rank");
            int bHeroes = handler.Superheroes.Count(h => h.Rank == "B-Rank");
            int cHeroes = handler.Superheroes.Count(h => h.Rank == "C-Rank");

            report.Add(totalNumberOfHeroes.ToString());
            report.Add(averageAge.ToString());
            report.Add(examScoreAverage.ToString());
            report.Add(sHeroes.ToString());
            report.Add(aHeroes.ToString());
            report.Add(bHeroes.ToString());
            report.Add(cHeroes.ToString());

            return report;
        }

        public void GenerateReportFile(FileHandler handler)
        {
            
            List<string> reportData = ReportInfo(handler);

            string reportPath = "C:\\Users\\thabz\\Downloads\\Prg282-TextFiles\\Superhero_Report.txt";

            using (StreamWriter writer = new StreamWriter(reportPath, false))
            {
                writer.WriteLine("=========================================");
                writer.WriteLine("        SUPERHERO PERFORMANCE REPORT      ");
                writer.WriteLine("=========================================");
                writer.WriteLine($"Report Generated On: {DateTime.Now}");
                writer.WriteLine("-----------------------------------------");
                writer.WriteLine($"Total Number of Heroes : {reportData[0]}");
                writer.WriteLine($"Average Age            : {reportData[1]} years");
                writer.WriteLine($"Average Exam Mark      : {reportData[2]}%");
                writer.WriteLine("-----------------------------------------");
                writer.WriteLine("Rank Distribution:");
                writer.WriteLine($"  S-Rank Heroes : {reportData[3]}");
                writer.WriteLine($"  A-Rank Heroes : {reportData[4]}");
                writer.WriteLine($"  B-Rank Heroes : {reportData[5]}");
                writer.WriteLine($"  C-Rank Heroes : {reportData[6]}");
                writer.WriteLine("=========================================");

            }

            MessageBox.Show($"Report successfully generated!\nSaved at:\n{reportPath}",
                            "Report Created",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

    }
}

