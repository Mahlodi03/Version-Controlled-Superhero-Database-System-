﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prg282Project
{
    public class Superhero
    {
        int id, age;
        string name, superPower, gender, rank, threatLevel;
        double examMark;

        public Superhero(int id, string name, string superPower, string gender, int age, double examMark, string rank, string threatLevel)
        {
            this.Id = id;
            this.Age = age;
            this.Name = name;
            this.SuperPower = superPower;
            this.Gender = gender;
            this.Rank = rank;
            this.ThreatLevel = threatLevel;
            this.ExamMark = examMark;
        }

        public int Id { get => id; set => id = value; }
        public int Age { get => age; set => age = value; }
        public string Name { get => name; set => name = value; }
        public string Gender { get => gender; set => gender = value; }
        public string SuperPower { get => superPower; set => superPower = value; }
        public string Rank { get => rank; set => rank = value; }
        public string ThreatLevel { get => threatLevel; set => threatLevel = value; }
        public double ExamMark { get => examMark; set => examMark = value; }


        public override string ToString()
        {
            return $"{Id}|{Name}|{SuperPower}|{Gender}|{Age}|{ExamMark}|{Rank}|{ThreatLevel}";
        }
    }
}
